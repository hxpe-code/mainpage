# YOUR PROJECT TITLE
#### Video Demo:  <URL https://youtu.be/r8xeRT_ZCgI>
#### Description:
This is my first webpage that I made myself.
On the main page theres already a lot.
The site welcomes you and it shows the Earth rotating.
Below that you can see your current time and the weather. 
The weather part is interesting because it shows your local weather, when you load the webpage it gets your ip address with IPSTACK and then uses openweathermap api to get the local 
weather for you. It really cool. Also it shows an Icon below it, this is related to your weather.
Then theres a login and register button.
You can choose to register as a new user or login if you already registered before.
Once you logged in it takes you to the main page, but before this I wanna tell you another cool thing. When you start the webserver using flask it runs a python program called create_tables.py, that one will create a databse called users.db. So everytime you download a program it will create the database for you. If you already have users.db then npothing will happen.
So on the Main  page you can see a welcome message and a menu bar.
On the top rigt of the page theres a logout button which you can use to logout.
In the middle theres 4 links.
The users page shows all registered usernames.
The search page is a basic google search, whatvere you search for it will search for on google in a new page.
The mind page is really cool, it uses IPSTACK to gather all the avaiable data about you.
It shows your IP address, the city you live in your ZIP code, your country, capital city and much more!
On the quote page it shows you a random quoute.
You can request a new one by clicking the button below the quote.
On every page expect the quote page you can find a Logout and Back button.
With the logout button you can logout it takes you back to the what I call null page ("/"). With the Back button you can go back to the main page.
Thank you for trying my website and have a little fun by exploring my code and the interesting API that I implemented.