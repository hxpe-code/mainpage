function updateLiveTime() {
    const currentTime = new Date();
    const hours = currentTime.getHours();
    const minutes = currentTime.getMinutes();
    const seconds = currentTime.getSeconds();

    const formattedTime = `${hours}:${minutes}:${seconds}`;
    document.getElementById('live-time').innerText = `Current Time: ${formattedTime}`;
}

// Update the live time every second
setInterval(updateLiveTime, 1000);

// Initial update
updateLiveTime();

async function fetchVisitorLocation() {
    try {
        console.log('Fetching visitor location...');
        const response = await fetch('http://api.ipstack.com/check?access_key=5bfc4086ce8ab9ce13c1fa2ac498849e');
        const data = await response.json();

        console.log('Visitor location response:', data);

        return data.city;
    } catch (error) {
        console.error('Error fetching visitor location:', error);
        return null;
    }
}


async function fetchWeatherData() {
    const apiKey = '759fac8ae17dc5d02e624437fb18e42f';
    
    // Fetch visitor location based on IP
    const visitorLocation = await fetchVisitorLocation();

    if (visitorLocation) {
        try {
            console.log('Fetching weather data for location:', visitorLocation);

            // Fetch weather data based on the visitor's city
            const response = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${visitorLocation}&appid=${apiKey}`);
            const data = await response.json();

            console.log('Weather data response:', data);

            const weatherDescription = data.weather[0].description;
            const temperature = (data.main.temp - 273.15).toFixed(2); // Convert to Celsius
            const iconCode = data.weather[0].icon;
            const iconElement = document.getElementById('weather-icon');
            iconElement.src = `http://openweathermap.org/img/wn/${iconCode}.png`;
            iconElement.alt = 'Weather Icon';
            const weatherData = `Weather: ${weatherDescription}, Temperature: ${temperature}°C`;
            document.getElementById('weather-data').innerText = weatherData;
        } catch (error) {
            console.error('Error fetching weather data:', error);
        }
    }
}


setInterval(fetchWeatherData, 600000);


updateLiveTime();
fetchWeatherData();

