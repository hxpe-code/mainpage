import sqlite3

# Connect to SQLite database (creates a new one if not exists)
connection = sqlite3.connect('users.db')
cursor = connection.cursor()

# Drop the existing 'users' table if it exists
cursor.execute('DROP TABLE IF EXISTS users')

# Create a new 'users' table
cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL
    )
''')

# Commit the changes and close the connection
connection.commit()
connection.close()
